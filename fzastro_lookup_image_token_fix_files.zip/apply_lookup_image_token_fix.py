from __future__ import annotations

from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path.cwd()
server_path = PROJECT_ROOT / "fzastro_ai" / "web_companion" / "server.py"
index_path = PROJECT_ROOT / "fzastro_ai" / "web_companion" / "static" / "index.html"

if not server_path.exists():
    raise SystemExit(f"Missing server.py: {server_path}")
if not index_path.exists():
    raise SystemExit(f"Missing index.html: {index_path}")

backup_root = PROJECT_ROOT / ".fzastro_patch_backups" / ("web_lookup_image_token_fix_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
backup_root.mkdir(parents=True, exist_ok=True)
(server_path.parent).mkdir(parents=True, exist_ok=True)
(index_path.parent).mkdir(parents=True, exist_ok=True)

(server_backup := backup_root / "server.py").write_text(server_path.read_text(encoding="utf-8"), encoding="utf-8")
(index_backup := backup_root / "index.html").write_text(index_path.read_text(encoding="utf-8"), encoding="utf-8")

server = server_path.read_text(encoding="utf-8")
start = server.find("def _request_token(request: Any) -> str:")
end = server.find("\ndef _model_to_dict", start)
if start == -1 or end == -1:
    raise SystemExit("Could not locate _request_token block in server.py")

new_request_token = '''def _request_token(request: Any) -> str:
    auth_header = str(request.headers.get("authorization", "")).strip()

    if auth_header.casefold().startswith("bearer "):
        return auth_header.split(" ", 1)[1].strip()

    header_token = str(request.headers.get("x-fzastro-token", "")).strip()
    if header_token:
        return header_token

    # Normal fetch() calls send X-FZAstro-Token, but <img src="..."> cannot set
    # custom headers.  Allow image asset URLs to carry the same token as a query
    # parameter so LOOKUP sky images render in LAN/iPad mode.
    return str(
        request.query_params.get("fzastro_token")
        or request.query_params.get("token")
        or ""
    ).strip()
'''
server = server[:start] + new_request_token + server[end:]
server_path.write_text(server, encoding="utf-8")

index = index_path.read_text(encoding="utf-8")
start = index.find("    function fileUrls(files) {")
end = index.find("\n    async function apiJson", start)
if start == -1 or end == -1:
    raise SystemExit("Could not locate fileUrls block in index.html")

new_file_urls = '''    function assetTokenQuery() {
      const token = tokenInput.value.trim();
      return token ? `&fzastro_token=${encodeURIComponent(token)}` : '';
    }

    function fileUrls(files) {
      const stamp = Date.now();
      return (files || [])
        .filter(path => /\\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(String(path)))
        .map(path => `/api/assets/file?path=${encodeURIComponent(path)}${assetTokenQuery()}&v=${stamp}`);
    }
'''
index = index[:start] + new_file_urls + index[end:]

# Add a clearer broken-image diagnostic without changing the layout.
old = """          img.addEventListener('load', scrollChatToBottom, { once: true });\n          strip.appendChild(img);"""
new = """          img.addEventListener('load', scrollChatToBottom, { once: true });\n          img.addEventListener('error', () => {\n            img.alt = 'Image failed to load. Check token/LAN access.';\n            img.title = 'Image failed to load. Check token/LAN access.';\n          }, { once: true });\n          strip.appendChild(img);"""
index = index.replace(old, new)

index_path.write_text(index, encoding="utf-8")

print("Patched LOOKUP image token handling.")
print(f"Backups saved under: {backup_root}")
print(f"Updated: {server_path}")
print(f"Updated: {index_path}")
