param(
    [string]$ProjectRoot = "D:\Dropbox\AI"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Set-Location $ProjectRoot
& ".\.venv\Scripts\python.exe" ".\apply_lookup_image_token_fix.py"
