param(
    [string]$ProjectRoot = "D:\Dropbox\AI"
)

$ErrorActionPreference = "Stop"

$source = Join-Path $PSScriptRoot "fzastro_ai\workers"
$target = Join-Path $ProjectRoot "fzastro_ai\workers"

if (-not (Test-Path $source)) {
    throw "Restore source not found: $source"
}

if (-not (Test-Path $target)) {
    New-Item -ItemType Directory -Path $target -Force | Out-Null
}

Copy-Item -Path (Join-Path $source "*.py") -Destination $target -Force

Write-Host "Restored worker files to: $target"
Write-Host "Check:" 
Write-Host "  Test-Path (Join-Path $target 'ollama_restart_worker.py')"
